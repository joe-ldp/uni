<template>
  <div id="app">
    <nav class="navbar navbar-expand navbar-dark bg-dark">
      <router-link to="/" class="navbar-brand">petshop</router-link>
      <div class="navbar-nav mr-auto">
        <li class="nav-item">
          <router-link to="/animals" class="nav-link">Animals</router-link>
        </li>
        <li class="nav-item">
          <router-link to="/add-animal" class="nav-link">Add</router-link>
        </li>
        <li class="nav-item">
          <router-link to="/users" class="nav-link">List Users</router-link>
        </li>
        <li class="nav-item">
          <router-link to="/add-users" class="nav-link">Add Users</router-link>
        </li>
      </div>
    </nav>

    <div class="container mt-3">
      <h2>Petshop Vue 3 example</h2>
      <router-view />
    </div>
  </div>
</template>

<script>
export default {
  name: "app"
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

<style scoped>
  .container h2 {
    text-align: center;
    margin: 25px auto;
  }
  </style>
