module.exports = {
    secret: "sad-supersecret-key"
};