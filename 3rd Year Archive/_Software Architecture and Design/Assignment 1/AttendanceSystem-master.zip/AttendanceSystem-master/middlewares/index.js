const authjwt = require("./authjwt");
const verifySignUp = require("./verifySignUp");
const verifySignUpStu = require("./verifySignUpStu");
module.exports = {
  authjwt,
  verifySignUp,
  verifySignUpStu
};