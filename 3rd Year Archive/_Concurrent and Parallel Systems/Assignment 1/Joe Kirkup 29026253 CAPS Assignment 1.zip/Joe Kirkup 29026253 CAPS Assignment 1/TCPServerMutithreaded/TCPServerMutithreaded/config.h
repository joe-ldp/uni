#ifndef __CONFIG_H
#define __CONFIG_H

//NOTE: Comment the next define to select the main to run:
//the main may be blocking or non-blocking waiting for data to be sent by the server

//#define NON_BLOCKING

#endif //__CONFIG_H

