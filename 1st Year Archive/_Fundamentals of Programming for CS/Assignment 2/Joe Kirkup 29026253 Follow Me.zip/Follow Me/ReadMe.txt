Press any key to start the game
Once the NPC has shown you the path, use the arrow keys to try and follow it
Every 0.8 seconds after you first move, your character will continue to move in that direction so make sure you're steering it right!