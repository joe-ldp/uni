package shu.cmscb;

import shu.cmscb.calculator.*;

import javax.swing.JTree;

public class Worker extends CalculatorBaseListener {
    private JTreeImpl jti;
    public JTree getJTree() { return this.jti.getTree(); }

    @Override
    public void enterProg(CalculatorParser.ProgContext ctx) {
        jti = new JTreeImpl("Program");
    }

    @Override
    public void exitProg(CalculatorParser.ProgContext ctx) {
        jti.exitNode();
    }

    @Override
    public void enterAssign(CalculatorParser.AssignContext ctx) {
        jti.enterNode("Assignment");
    }

    @Override
    public void exitAssign(CalculatorParser.AssignContext ctx) {
        jti.exitNode();
    }

    @Override
    public void enterAdd(CalculatorParser.AddContext ctx) {
        jti.enterNode("Add");
    }

    @Override
    public void exitAdd(CalculatorParser.AddContext ctx) {
        jti.exitNode();
    }

    @Override
    public void enterOperand(CalculatorParser.OperandContext ctx) {
        jti.addLeaf(ctx.getText());
    }
}

