package shu.cmscb;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import shu.cmscb.calculator.*;

import javax.swing.*;
import java.awt.*;

public class Main extends JFrame {

    private JTreeImpl jti;
    private Worker worker;

    public Main() {
        try {
            ANTLRInputStream input = new ANTLRInputStream(System.in);
            CalculatorLexer lexer = new CalculatorLexer(input);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            CalculatorParser parser = new CalculatorParser(tokens);

            ParseTree tree = parser.prog();
            ParseTreeWalker walker = new ParseTreeWalker();
            worker = new Worker();
            walker.walk(worker, tree);
        } catch (Exception ex) {
            System.out.println("Exception whilst creating parse tree.");
        }
    }

    public void drawUI() {
        add(worker.getJTree());

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Display the structure of a program");
        this.setSize(new Dimension(400,300));
        this.setLocation(new java.awt.Point(200, 200));
        this.pack();
        this.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Main main = new Main();
                main.drawUI();
            }
        });
    }
}
