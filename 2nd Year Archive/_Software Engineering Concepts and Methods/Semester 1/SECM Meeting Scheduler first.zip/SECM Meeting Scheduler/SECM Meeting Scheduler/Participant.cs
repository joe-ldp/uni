﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SECM_Meeting_Scheduler
{
    class Participant
    {
        private Person person;
        private bool important;
    }
}