public class ADS2List {
}
