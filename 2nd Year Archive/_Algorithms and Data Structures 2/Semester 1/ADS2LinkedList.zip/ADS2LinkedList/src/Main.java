public class Main {

    public static void main(String[] args) {
        // All your code to implement the behaviour of the requested algorithms and
        // data structures need to go into the classes provided as this main method
        // will be replaced when it is being evaluated using pre-defined tests

        //Test your code below
    }
}
