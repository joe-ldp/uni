public class ADS2LinkedList {
    //Members to build the singly linked list


    // Default Constructor function
    public ADS2LinkedList()
    {
    }

    //Return the number of items contained within this data structure.
    //Use tail recursion for this task
    public int GetNoOfItems()
    {
        return 0;
    }

    /* Returns the value held at index (base zero) or -1 if the index
     * is out of bounds */
    public int GetItemByIndex(int index)
    {
        return 0;
    }


    /* Adds value to the end of the data structure */
    public void AddItem(int value)
    {
    }

    /* Inerts value into the data structure at index (base zero) or at the end
     * if there are less items in the data structure than index */
    public void InsertItem(int index, int value)
    {
    }

    /* Removes the item at index from the data structure - if index is out of
     * bounds then the data structure remains unchanged */
    public void DeleteItem(int index)
    {
    }

    /*List all the items in the list as a String,
     *A useful format is Item0, Item1, Item2,..., Item n
     */
    public String ListAllIItem()
    {
        return null;
    }

}
