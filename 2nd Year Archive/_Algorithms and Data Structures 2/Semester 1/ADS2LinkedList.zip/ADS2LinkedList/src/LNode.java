/* This class is used within the ADS2LinkedList data collection as the link nodes
 * This is a singly linked list.
 * This Linked List if for storing integer data type
 */
public class LNode {

}
