public class CustomerQueue {

    // Default Constructor
    CustomerQueue(){

    }
}
