//Since we are comparing strings, you need to use StringA.compareToIgnoreCase(StringB)
//to sort items under alphabetical order
public class Sorting {
    //Create a sorting algorithm using Insertion Sort
    public static void InsertionSort(String[] data) {

    }

    //Create a sorting algorithm using Merge Sort
    public static void MergeSort(String[] data) {

    }

    //Create a sorting algorithm using Quick Sort
    public static void QuickSort(String[] data){

    }


    //Create some other private helper functions.
}
