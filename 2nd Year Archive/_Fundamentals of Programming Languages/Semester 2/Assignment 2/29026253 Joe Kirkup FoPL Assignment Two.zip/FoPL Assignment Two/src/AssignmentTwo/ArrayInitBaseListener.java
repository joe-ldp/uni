package AssignmentTwo;

public class ArrayInitBaseListener
{

}